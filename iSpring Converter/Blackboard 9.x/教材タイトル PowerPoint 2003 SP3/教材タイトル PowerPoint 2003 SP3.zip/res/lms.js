iSpring = {};
iSpring.bb = {};

iSpring.bb.Lms = function(player)
{
	/**
	 * Initializes lms connector.
	 */
	this.initialize = function(player)
	{
		this.player = player;	
		this.countSlides = player.presentation().slides().count();

		var playbackController = player.view().playbackController();
		playbackController.slideChangeEvent().addHandler(this.onCurrentSlideIndexChanged, this);
	};
    
    /**
     * Handles presentation slide index changed event.
     */
	this.onCurrentSlideIndexChanged = function(slideIndex)
	{
		if (this.currentSlideIndex == undefined)
		{
			this.getLmsApi().playbackStarted();
		}

		this.currentSlideIndex = slideIndex;
		this.getLmsApi().currentSlideIndexChanged(this.currentSlideIndex, this.countSlides);
	};

    /**
     * Returns lms's api.
     */
	this.getLmsApi = function()
	{
		if (this.lmsApi == undefined)
		{
			this.lmsApi = new iSpring.bb.Lms.Api();
		}
		return this.lmsApi;
	};


	/**
     * Close window handler.
     */
	this.closeLms = function()
	{
		this.onCallCloseRequest();
	}
	
	this.initialize(player);
};


iSpring.bb.Lms.Api = function()
{
	/**
	 * Handles playback started event.
	 */
	this.playbackStarted = function()
	{
		this.getBbApi().initialize();
	};

    /**
     * Handles playback completed event.
     */
	this.playbackCompleted = function()
	{
	};

    /**
     * Terminates playback.
     */
	this.terminate = function()
	{
		this.getBbApi().terminate();
	};

    /**
     * Handles current slide changed event.
     */
	this.currentSlideIndexChanged = function(slideIndex, countSlides)
	{
		if (this.viewedSlides == undefined)
		{
			this.viewedSlides = {};
			this.countViewedSlides = 0;
		}

		if ( !this.viewedSlides[slideIndex] )
		{
			this.viewedSlides[slideIndex] = true;
			++this.countViewedSlides;

			var itemScore = this.countViewedSlides;
			var itemId = "slides";

			var api = this.getBbApi();						
			var gradeInfo = api.getItemGradeInfo(itemId);
			if (gradeInfo)
			{
				itemScore = gradeInfo.maxScore / countSlides * this.countViewedSlides;
			}
			
			api.setItemScore(itemId, itemScore);
			api.flush();
		}
	};

    /**
     * Handles quiz finished event.
     */
	this.quizFinished = function(quizId, pointScore, percentScore, passed, totalScore)
	{
    	var api = this.getBbApi();
    	api.setItemScore(quizId, pointScore);
    	api.setItemPercentage(quizId, percentScore * 100);
    	api.setItemPassFlag(quizId, passed);
    	api.setItemMaxScore(quizId, totalScore);
    	api.flush();
	};

    /**
     * Returns blackboard api.
     */
	this.getBbApi = function()
	{
		if (this.bbApi == undefined)
		{
			this.bbApi = this.findBbApi(window.parent);
		}
		return this.bbApi;
	};

	/**
     * Tries to find blackboard's api.
     */
	this.findBbApi = function(context)
	{
		if (context.iSpringAPI != undefined)
		{
			return context.iSpringAPI;
		}

		if (context.parent != context)
		{
			return this.findBbApi(context.parent);
		}
		return null;
	};
};